#include<bits/stdc++.h>
using namespace std;

namespace TYC
{
	typedef pair<int,int> pa;
	const int N=1e5+10;
	const int M=N<<1;
	const int inf=0x3f3f3f3f;

	int n,m,q,cnt,node,val[M],h[N],Head[M],size[M],son[M],top[M],dfn[M],dep[M],fa[M],w[M];
	priority_queue<int,vector<int>,greater<int> > pq[M];

	inline int read()
	{
		int x=0,f=0;char ch=getchar();
		while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
		while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
		return f?-x:x;
	}

	inline void write(int x)
	{
		if(x<0) putchar('-'),x=-x;
		if(!x) putchar('0');
		else
		{
			int len=0;
			static int bask[50];
			while(x) bask[++len]=x%10,x/=10;
			for(;len;len--) putchar('0'+bask[len]);
		}
		putchar('\n');
	}

	struct edge
	{
		int to,next;
	}E[N<<1];

	inline void add(int *H,const int u,const int v)
	{
		E[++cnt]=(edge){v,H[u]};
		H[u]=cnt;
		E[++cnt]=(edge){u,H[v]};
		H[v]=cnt;
	}

	void Tarjan(const int u,const int pre)
	{
		static int tim,top,bel[N],low[N],vistim[N];
		static pa sta[N];
		vistim[u]=low[u]=++tim;
		for(int i=h[u];i;i=E[i].next)
		{
			int v=E[i].to;
			if((i^1)==pre) continue;
			if(dfn[v]) 
			{
				low[u]=min(low[u],vistim[v]);
				if(vistim[v]<vistim[u]) sta[++top]=pa(u,v);
			}
			else
			{
				sta[++top]=pa(u,v);
				Tarjan(v,i);
				low[u]=min(low[u],low[v]);
				if(low[v]>=dfn[u])
				{
					node++;
					int x,y;
					do 
					{
						x=sta[top].first,y=sta[top].second;
						if(bel[x]!=node) 
							bel[x]=node,add(Head,node,x),pq[node].push(val[x]);
						if(bel[y]!=node) 
							bel[y]=node,add(Head,node,y),pq[node].push(val[y]);
					}
					while(x!=u&&y!=v);
					val[node]=pq[node].top();
				}
			}
		}
	}

	void dfs(const int u)
	{
		size[u]=1;
		for(int i=Head[u];i;i=E[i].next)
		{
			int v=E[i].to;
			if(v==fa[u]) continue;
			fa[v]=fa[u],dep[v]=dep[u]+1;
			dfs(v);
			size[u]+=size[v];
			if(size[v]>size[son[u]]) son[u]=v;
		}
	}

	void dfs(const int u,const int ance)
	{
		static int tim;
		dfn[u]=++tim;
		w[tim]=val[u];
		if(son[u]) dfs(son[u],ance);
		for(int i=Head[u];i;i=E[i].next)
		{
			int v=E[i].to;
			if(v==fa[u]||v==son[u]) continue;
			dfs(v,v);
		}
	}

	namespace Tree
	{
		int mn[M<<2];

		#define ls root<<1
		#define rs root<<1|1
		
		inline void update(const int root)
		{
			mn[root]=min(mn[ls],mn[rs]);
		}

		void build(const int root,const int l,const int r)
		{
			if(l==r) {mn[root]=w[l];return;}
			int mid=(l+r)>>1;
			build(ls,l,mid),build(rs,mid+1,r);
			update(root);
		}

		void modify(const int root,const int l,const int r,const int pos,const int value)
		{
			if(l==r) {mn[root]=value;return;}
			int mid=(l+r)>>1;
			if(pos<=mid) modify(ls,l,mid,pos,value);
			else modify(rs,mid+1,r,pos,value);
		}

		int query(const int root,const int l,const int r,const int s,const int e)
		{
			if(s<=l&&r<=e) return mn[root];
			int mid=(l+r)>>1,ans=inf;
			if(s<=mid) ans=min(ans,query(ls,l,mid,s,e));
			if(e>mid) ans=min(ans,query(rs,mid+1,r,s,e));
			return ans;
		}
	}

	inline void modify(const int pos,const int value)
	{
		Tree::modify(1,1,n,pos,value);

	}

	inline int query(int u,int v)
	{
		int ans=inf;
		while(top[u]!=top[v])
		{
			if(dep[top[u]]<dep[top[v]]) swap(u,v);
			ans=min(ans,Tree::query(1,1,n,dfn[top[u]],dfn[u]));
			u=fa[top[u]];
		}
		if(dep[u]>dep[v]) swap(u,v);
		return min(ans,Tree::query(1,1,n,dfn[u],dfn[v]));
	}

	void work()
	{
		node=n=read(),m=read(),q=read();
		for(int i=1;i<=n;i++) val[i]=read();
		cnt=1;
		for(int i=1;i<=n;i++)
		{
			int u=read(),v=read();
			add(h,u,v);
		}
		cnt=0;
		Tarjan(1,0);
		dfs(1);
		dfs(1,1);
		Tree::build(1,1,n);
		char ch;
		while(q--)
		{
			do ch=getchar(); while(!isalpha(ch));
			if(ch=='A') write(query(read(),read()));
			else 
			{
				int pos=read(),value=read();
				modify(pos,value);
			}
		}
	}
}

int main()
{
	TYC::work();
	return 0;
}
